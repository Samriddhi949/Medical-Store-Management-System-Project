package com.project;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author Tom Marvolo Riddle
 */

public class Main
{
    public static void main(String args[]) 
    {
       new Welcome();
    }
}
